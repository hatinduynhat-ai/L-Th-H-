# Vương Quốc Toán Học Lớp 2 - Tập 1

Ứng dụng học Toán tương tác chuẩn SGK Toán 2 Tập 1 (Bộ sách Kết Nối Tri Thức Với Cuộc Sống).
Bao gồm:
- Toàn bộ 36 bài học và chuyên đề theo lộ trình chuẩn Bộ GD&ĐT.
- Gia sư AI Robo Toán thông minh, kiên nhẫn khích lệ học sinh 7-8 tuổi.
- Mô hình trực quan sinh động: Bó que tính chục/đơn vị, tia số nhảy bước, cân thăng bằng đĩa, đồng hồ kim xoay thời gian thực, tách-gộp số, hình học & đoạn thẳng.
- Hệ thống bài tập đa dạng, tương tác trực tiếp, chấm điểm và thưởng sao tự động.
- Trung tâm trò chơi toán học (Truy tìm kho báu, Đua xe tính nhẩm, Nối cặp thẻ bài).
- Cổng quản lý dành cho Phụ huynh & Giáo viên (in phiếu bài tập, xem thống kê, điều chỉnh độ khó).

---

## 🚀 Hướng Dẫn Cài Đặt & Chạy Trên Máy Của Bạn (Local Setup)

### 1. Yêu cầu hệ thống:
- [Node.js](https://nodejs.org/) phiên bản 18 trở lên (khuyên dùng Node 20 hoặc 22).
- Trình duyệt hiện đại (Chrome, Edge, Firefox, Safari).

### 2. Cài đặt các thư viện phụ thuộc:
Mở terminal trong thư mục này và chạy:
```bash
npm install
```

### 3. Cấu hình biến môi trường (tùy chọn):
Tạo file `.env` từ `.env.example`:
```bash
cp .env.example .env
```
Nếu muốn sử dụng tính năng Gia sư AI Robo Toán với Google Gemini API:
Điền khóa `GEMINI_API_KEY` của bạn vào file `.env`. Nếu không có API Key, hệ thống vẫn hoạt động mượt mà với bộ phản hồi sư phạm thông minh tích hợp sẵn!

### 4. Khởi động môi trường phát triển:
```bash
npm run dev
```
Sau đó mở trình duyệt tại: `http://localhost:3000`

### 5. Đóng gói triển khai (Production Build):
```bash
npm run build
npm run start
```

---
Chúc các bạn nhỏ học tập thật vui và ngày càng giỏi Toán! 🌟
