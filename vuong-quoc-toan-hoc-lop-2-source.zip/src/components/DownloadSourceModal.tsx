import React, { useState } from 'react';
import {
  Download,
  FolderArchive,
  Terminal,
  Check,
  Copy,
  ExternalLink,
  X,
  FileCode2,
  Cpu,
  Sparkles,
  Layers,
  BookOpen,
} from 'lucide-react';
import { sounds } from '../utils/soundEffects';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadSourceModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [copiedStep, setCopiedStep] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownload = async () => {
    sounds.playPop();
    setIsDownloading(true);
    setDownloadSuccess(false);

    try {
      // Trigger fetch to download file blob
      const response = await fetch('/api/download-source');
      if (!response.ok) {
        throw new Error('Không thể tải mã nguồn');
      }

      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = 'vuong-quoc-toan-hoc-lop-2-source.zip';
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(downloadUrl);
      document.body.removeChild(link);

      sounds.playStar();
      setDownloadSuccess(true);
    } catch (err) {
      console.warn('Direct blob download failed, falling back to window location:', err);
      // Fallback: direct browser navigation to download endpoint
      window.location.href = '/api/download-source';
      setDownloadSuccess(true);
    } finally {
      setIsDownloading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    sounds.playPop();
    navigator.clipboard.writeText(text);
    setCopiedStep(id);
    setTimeout(() => {
      setCopiedStep(null);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border-4 border-amber-300 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-amber-400 via-orange-400 to-rose-400 p-5 sm:p-6 text-white relative">
          <button
            onClick={() => {
              sounds.playPop();
              onClose();
            }}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition cursor-pointer"
            title="Đóng cửa sổ"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm border-2 border-white/40 flex items-center justify-center text-2xl shadow-inner">
              📦
            </div>
            <div>
              <div className="text-xs font-black uppercase tracking-wider text-amber-100 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Mã Nguồn Mở Trọn Bộ (Full Source Code)
              </div>
              <h3 className="text-xl sm:text-2xl font-black drop-shadow-sm">
                Tải Mã Nguồn Ứng Dụng
              </h3>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          {/* Main Download Action Banner */}
          <div className="bg-amber-50 rounded-2xl p-4 sm:p-5 border-2 border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <h4 className="font-black text-amber-950 text-base flex items-center justify-center sm:justify-start gap-2">
                <FolderArchive className="w-5 h-5 text-amber-600" />
                Gói mã nguồn nén (ZIP)
              </h4>
              <p className="text-xs text-amber-800/90 font-medium">
                Bao gồm toàn bộ React 19, TypeScript, Express, 36 bài học, gia sư AI Robo và mô hình tương tác.
              </p>
            </div>

            <button
              onClick={handleDownload}
              disabled={isDownloading}
              className={`w-full sm:w-auto px-6 py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2.5 shadow-lg transition-all transform active:scale-95 cursor-pointer shrink-0 ${
                isDownloading
                  ? 'bg-slate-400 text-white cursor-wait'
                  : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white hover:shadow-orange-200'
              }`}
            >
              {isDownloading ? (
                <>
                  <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Đang nén & chuẩn bị...</span>
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  <span>Tải Xuống Ngay (.ZIP)</span>
                </>
              )}
            </button>
          </div>

          {downloadSuccess && (
            <div className="p-3 bg-emerald-50 border-2 border-emerald-300 rounded-2xl text-emerald-800 text-xs font-bold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                Đang bắt đầu tải xuống file <strong>vuong-quoc-toan-hoc-lop-2-source.zip</strong>. Vui lòng kiểm tra thư mục Downloads trên máy của bạn!
              </span>
            </div>
          )}

          {/* Highlights of Included Source Code */}
          <div className="space-y-2">
            <h4 className="text-xs font-black uppercase text-slate-500 tracking-wider">
              Nội dung gói mã nguồn bao gồm:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2">
                <FileCode2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-800">Toàn bộ 36 bài học SGK:</span>
                  <p className="text-slate-500 text-[11px]">Nội dung lý thuyết, bài tập tương tác chuẩn Toán 2 Tập 1.</p>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2">
                <Cpu className="w-4 h-4 text-purple-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-800">Gia sư AI Robo Toán:</span>
                  <p className="text-slate-500 text-[11px]">Backend Express & Gemini API với lời giải sư phạm từng bước.</p>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2">
                <Layers className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-800">Bộ 6 mô hình trực quan:</span>
                  <p className="text-slate-500 text-[11px]">Bó que tính, tia số, đồng hồ kim xoay, cân thăng bằng đĩa...</p>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-start gap-2">
                <BookOpen className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-800">Cổng Phụ Huynh & GV:</span>
                  <p className="text-slate-500 text-[11px]">In phiếu bài tập, thống kê kết quả học tập và điều chỉnh mức độ.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Start Guide */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase text-slate-500 tracking-wider flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-slate-700" />
              Cách chạy ứng dụng trên máy tính của bạn:
            </h4>

            <div className="space-y-2 text-xs">
              {/* Step 1 */}
              <div className="bg-slate-900 text-slate-100 p-3 rounded-2xl space-y-1.5 font-mono">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans font-bold">
                  <span>Bước 1: Giải nén file ZIP vừa tải về và mở thư mục trong Terminal</span>
                </div>
              </div>

              {/* Step 2 */}
              <div className="bg-slate-900 text-slate-100 p-3 rounded-2xl space-y-1.5 font-mono">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans font-bold">
                  <span>Bước 2: Cài đặt thư viện dependencies</span>
                  <button
                    onClick={() => copyToClipboard('npm install', 'step2')}
                    className="flex items-center gap-1 text-amber-400 hover:text-amber-300 font-sans transition cursor-pointer"
                  >
                    {copiedStep === 'step2' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Đã sao chép</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Sao chép</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="text-amber-300 font-bold select-all">npm install</div>
              </div>

              {/* Step 3 */}
              <div className="bg-slate-900 text-slate-100 p-3 rounded-2xl space-y-1.5 font-mono">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans font-bold">
                  <span>Bước 3: Chạy ứng dụng và mở trên trình duyệt</span>
                  <button
                    onClick={() => copyToClipboard('npm run dev', 'step3')}
                    className="flex items-center gap-1 text-amber-400 hover:text-amber-300 font-sans transition cursor-pointer"
                  >
                    {copiedStep === 'step3' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Đã sao chép</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Sao chép</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="text-emerald-400 font-bold select-all">npm run dev</div>
                <div className="text-[11px] text-slate-400 pt-1 font-sans">
                  Ứng dụng sẽ chạy tại: <span className="text-blue-400 underline">http://localhost:3000</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 text-xs">
          <div className="text-slate-500 font-medium">
            Có sẵn file <code className="bg-slate-200 px-1 py-0.5 rounded text-slate-700">README.md</code> hướng dẫn chi tiết bên trong file ZIP.
          </div>
          <button
            onClick={() => {
              sounds.playPop();
              onClose();
            }}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
